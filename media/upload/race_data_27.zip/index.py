#coding=utf-8
import web
import requests
import calendar

urls = (
    '/', 'index',
    '/calendar.html','rili',
    '/fanyi.html','fanyi',
    '/resume.html','resume',
)


class index:
    def GET(self):
        return render.index()
    
class resume:
    def GET(self):
        return render.resume()
    
class rili:
    def GET(self):
        return render.riliWeb("2022","09",calendar.month(2022,9))
    
    def POST(self):
        webData = web.input()
        year = webData.get("yearInput","2022")
        month = webData.get("monthInput","2022")
        data = calendar.month(int(year),int(month))
        return render.riliWeb(year,month,data)



  
class fanyi:
    def GET(self):
        q = "Python"
        explainList = [
            [1,"n. 巨蟒；大蟒；丹舌; n. （Python）人名；（法）皮东"],
            [2,"n. 蟒蛇（python 的复数）"],
            [3,"adj. 预言的；神谕的；大蟒似的"],
            [4,"n. 女预言家；女巫；古希腊德尔菲的太阳神殿的女祭司"],
            [5,"adj. 皮东风格的；搞笑的；奇怪的"]
        ]
        return render.youdao(q,explainList)
        
    def POST(self):
        webData = web.input()
        q = webData.get("q")
        url = "https://dict.youdao.com/suggest?num=5&ver=3.0&doctype=json&cache=false&le=en&q="+q
        response = requests.get(url)
        data = response.json()

        explainList = []
        i = 1
        for t in data["data"]["entries"]:
            explainList.append([i,t["explain"]])
            i+=1
        return render.youdao(q,explainList)

render = web.template.render('templates/')
if __name__ == "__main__":
    app = web.application(urls, globals())
    app.run()
